#ifndef CLIENT_REG
#define CLIENT_REG
#include "Client.h"
#include <vector>
#include <string>
#include <iostream>

const double TAUX_REDUC_REGULIER = 0.1;
const double TAUX_REDUC_PRESTIGE = 0.2;
const double SEUIL_DEBUT_REDUCTION = 75;
const double SEUIL_LIVRAISON_GRATUITE = 200;

class ClientRegulier : public Client
{
public:
	ClientRegulier();
	ClientRegulier(string nom , string prenom, int tailleGroupe ,int nbPoints);


	//Accesseurs
	int getNbPoints();


	//Autres M�thodes
	void augmenterNbPoints(int bonus);
	friend ostream & operator<<(ostream & os, const ClientRegulier& client);
	

protected:
	int nbPoints_;
};
#endif
